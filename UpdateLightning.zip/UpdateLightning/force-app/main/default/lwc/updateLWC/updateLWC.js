import { LightningElement,track } from 'lwc';
import { updateRecord } from 'lightning/uiRecordApi';
import ID_FIELD from '@salesforce/schema/Test_List__c.Id'; // Referring to Id field of custom setting
import FIRSTNAME_FIELD from '@salesforce/schema/Test_List__c.Name'; // Referring to Name field of custom setting

export default class UpdateLWC extends LightningElement {
    @track hasError = false;
@track errorMessage = '';
@track fields ={};

handleUpdate(){

//const fields = {};
this.fields[ID_FIELD.fieldApiName] = '0012v00002Ut73iAAB'; //Hardcoded the id value of the custom setting record
this.fields[FIRSTNAME_FIELD.fieldApiName] = 'Record Updated';
const recordInput = { fields : this.fields };

//Using the update method
updateRecord(recordInput)
.then(() => {
// eslint-disable-next-line no-console
console.log('Success');
})
.catch(error => {
this.hasError = true;
this.errorMessage = JSON.stringify(error);
// eslint-disable-next-line no-console
console.log('Error' + JSON.stringify(error));
});


}
}